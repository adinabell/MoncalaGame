package moncalaGame;

public class Moncala  extends Pit
{

	private int count;
	
	
	public  Moncala() {
		
		super(0);
		
				
	}}
	
	
